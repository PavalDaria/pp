import asyncio


async def suma(name, queue):
    while not queue.empty():
        number = await queue.get()
        s = sum(range(1, number + 1))
        await asyncio.sleep(1)  # ca sa puna workeri diferiti
        print(f"Task {name}: suma de la 1 la {number} = {s}")
        queue.task_done()


async def main():
    queue = asyncio.Queue()
    queue.put_nowait(2)
    queue.put_nowait(3)
    queue.put_nowait(4)
    queue.put_nowait(10)

    tasks = []
    for i in range(4):
        task = asyncio.create_task(suma(f'worker-{i}', queue))
        tasks.append(task)

    await queue.join()

    for task in tasks:
        task.cancel()

    await asyncio.gather(*tasks, return_exceptions=True)


if __name__ == '__main__':
    asyncio.run(main())

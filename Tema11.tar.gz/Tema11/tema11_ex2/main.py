import shlex
import subprocess

if __name__ == '__main__':
    command_line = input()
    args =[ shlex.split(c.strip()) for c in command_line.split("|")]
    print(args)
    p1 = None
    for index, arg in enumerate(args):
        if index == 0:
            p2 = subprocess.Popen(arg, stdin=None, stdout=subprocess.PIPE)
        else:
            p2 = subprocess.Popen(arg, stdin=p1.stdout, stdout=subprocess.PIPE)
            p1.stdout.close()
        p1 = p2
    output, err = p1.communicate()
    print(output.decode())

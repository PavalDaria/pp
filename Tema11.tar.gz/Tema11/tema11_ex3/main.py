from threading import Thread
from queue import Queue


class ThreadPool:
    def __init__(self, nthreads):
        self.tasks = Queue()
        self.threads = []
        self.active = True

        for i in range(nthreads):
            t = Thread(target=self.worker)
            t.start()
            self.threads.append(t)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.tasks.join()
        self.terminate()
        self.join()

    def worker(self):
        while self.active:
            f, args = self.tasks.get()
            if f == 'STOP':
                break
            f(*args)
            self.tasks.task_done()

    def run_segments(self, f, segment):
        for item in segment:
            f(item)

    def split_work(self, data, n):
        k, m = divmod(len(data), n)
        result = []
        start = 0

        for i in range(n):
            end = start + k + (1 if i < m else 0)
            result.append(data[start:end])
            start = end

        return result

    def map(self, f, iterable):
        segments = self.split_work(iterable, len(self.threads))
        for segment in segments:
            self.tasks.put((self.run_segments, (f, segment)))

    def terminate(self):
        self.active = False
        for i in self.threads:
            self.tasks.put(('STOP', ()))

    def join(self):
        for t in self.threads:
            t.join()


def suma(x):
    print(f"\nsuma de la 1 la {x} = {sum(range(1, x + 1))} ")


if __name__ == '__main__':
    with ThreadPool(4) as pool:
        pool.map(suma, [1, 2, 3, 4, 5, 6, 7, 8])

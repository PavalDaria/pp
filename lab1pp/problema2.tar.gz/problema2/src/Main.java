import java.io.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException{
        String fileName="input.txt";
        FileReader fileReader=new FileReader(fileName);
        BufferedReader br=new BufferedReader(fileReader);
        String n=br.readLine();
        String y=",.:;'?!";
        for(int j=0;j<n.length();j++)
        {
            char c=n.charAt(j);
            if(y.indexOf(c)!=-1)
            {
                n=n.replace(c,' ');
            }
        }
        System.out.println(n);
        System.out.println("1-eliminare litere mari, 2-eliminare litere mici");
        Scanner input=new Scanner(System.in);
        String a=input.nextLine();
        int x=Integer.parseInt(a);
        if(x==1)
        {
            for(int j=0;j<n.length();j++)
            {
                char c=n.charAt(j);
                if(Character.isUpperCase(c))
                {
                    n=n.replace(c,' ');
                }
            }
        }
        else
        {
            for(int j=0;j<n.length();j++)
            {
                char c=n.charAt(j);
                if(Character.isLowerCase(c))
                {
                    n=n.replace(c,' ');
                }
            }
        }
        System.out.println(n);
    }
}
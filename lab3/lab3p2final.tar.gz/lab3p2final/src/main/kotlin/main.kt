import java.util.regex.Pattern

fun main() {
    // Exemplu de text
    val ebookText = """
        Autor: Ion Popescu

       CAPITOL 2

        titlu: bla bla
        Textul poate contine multiple    spatii      si  
        unele          pagini ar putea  avea   numere.  1234
        Avem caractere "ă" în loc de "â".

        
    """

    var processedText = removeMultipleSpaces(ebookText)
    println(processedText)
    processedText = removeMultipleNewlines(processedText)
    println(processedText)
    processedText = removePageNumbers(processedText)
    println(processedText)
    processedText = removeAuthorName(processedText)
    println(processedText)
    processedText = removeChapterTitles(processedText)
    println(processedText)
    processedText = correctRomanianCharacters(processedText)

    println(processedText)
}


fun removeMultipleSpaces(text: String): String {
    return text.replace("\\s+".toRegex(), " ")
}


fun removeMultipleNewlines(text: String): String {
    return text.replace("\\n+".toRegex(), "\n")
}


fun removePageNumbers(text: String): String {
    return text.replace("\\s+\\d+\\s+".toRegex(), " ")
}


fun removeAuthorName(text: String): String {
    val authorPattern = "(?i)Autor:.*\n".toRegex()
    return text.replace(authorPattern, "")
}


fun removeChapterTitles(text: String): String {
    val chapterPattern = "(?i)Capitolul\\s+\\d+".toRegex()
    return text.replace(chapterPattern, "")
}


fun correctRomanianCharacters(text: String): String {
    return text.replace("ă", "â")
}
import java.util.*

class Movie(private val title: String, private val duration: Int, private val price: Double) {
    fun getPrice(): Double {
        return price
    }

    fun getTitle(): String {
        return title
    }
}
class Seat(private val num: Int, private var isAvailable: Boolean = true) {
    fun getAvailable(): Boolean {
        return isAvailable
    }
    fun setAvailable(b: Boolean) {
        isAvailable = b
    }

    fun getNum(): Int {
        return num
    }
}
interface PaymentMethod {
    fun pay(fee: Double): Boolean
}
class CashPayment(private var availableAmount: Double): PaymentMethod {
    override fun pay(fee: Double): Boolean {
        return if(availableAmount > fee) {
            println("Paid using Cash")
            true
        } else{
            println("Not paid")
            false
        }
    }
}
class BankAccount(
    private var availableAmount: Double,
    private val cardNumber: String,
    private val expirationDate: String,
    private val cvvCode: Int,
    private val userName: String
) {
    fun updateAmount(value: Double) : Boolean {
        if(availableAmount>value)
        {
            availableAmount -= value
            return true
        }
        else
            return false

    }
    fun getAvailableAmount() = availableAmount
    fun getCardNumber(): String {
        return cardNumber
    }
}
class CardPayment(private val bankAccount: BankAccount): PaymentMethod {
    override fun pay(fee: Double): Boolean {
        if(bankAccount.getAvailableAmount()>fee)
        {
            println("Paid using Card (${bankAccount.getCardNumber()})")
            bankAccount.updateAmount(fee)
            return true
        }
        else
        {
            return false
        }

    }

}
class Booking(private val movie: Movie,private val seat: Seat, private val paymentMethod: PaymentMethod) {
    fun confirmBooking(): Boolean{
        return if (seat.getAvailable()) {
            seat.setAvailable(false)
            paymentMethod.pay(movie.getPrice())
        } else {
            println("Seat already taken!")
            false
        }
    }
}
fun main() {

    val movie = Movie("The Lord of The Rings", 300, 55.5)

    val seat1 = Seat(1, true)
    val seat2 = Seat(2, true)

    println("Selectează un loc: (1 sau 2)")
    val selectedSeatNumber = readLine()?.toIntOrNull()
    val selectedSeat = if (selectedSeatNumber == 1) seat1 else seat2

    println("Alege metoda de plată: (1 - Cash, 2 - Card)")
    val paymentChoice = readLine()?.toIntOrNull()

    val paymentMethod: PaymentMethod = when (paymentChoice) {
        1 -> CashPayment(56.0)
        2 -> CardPayment(BankAccount(220.20,"1234-5678-9812-3456", "12-12-2028",123, "Mara"))
        else -> {
            println("Metodă de plată invalidă!")
            return
        }
    }


    val booking = Booking(movie, selectedSeat, paymentMethod)
    if (booking.confirmBooking()) {
        println(" Rezervarea a fost confirmată pentru filmul ${movie.getTitle()} la locul ${selectedSeat.getNum()}.")
    } else {
        println(" Rezervarea a eșuat.")
    }
}

import java.io.File
import java.io.IOException
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Scanner

data class Note(val author: String, val content: String) {
    val timestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))

    override fun toString(): String {
        return "Author: $author\nCreated At: $timestamp\nContent:\n$content"
    }
}

class User(val name: String) {
    override fun toString(): String {
        return "User: $name"
    }
}

class NoteManager(private val notesDirectory: String) {

    init {
        val dir = File(notesDirectory)
        if (!dir.exists()) {
            dir.mkdir()
        }
    }

    fun createNote(note: Note) {
        val fileName = "${notesDirectory}/${note.timestamp.replace(":", "-")}_${note.author}.txt"
        try {
            File(fileName).writeText(note.toString())
            println("Note saved as $fileName")
        } catch (e: IOException) {
            println("Failed to save note: ${e.message}")
        }
    }

    fun listNotes() {
        val dir = File(notesDirectory)
        val files = dir.listFiles()
        if (files.isNullOrEmpty()) {
            println("No notes available.")
        } else {
            files.forEachIndexed { index, file -> println("${index + 1}. ${file.name}") }
        }
    }

    fun loadNote(index: Int) {
        val dir = File(notesDirectory)
        val files = dir.listFiles()
        if (files != null && index in 1..files.size) {
            val selectedFile = files[index - 1]
            println("Note content:\n" + File(selectedFile.path).readText())
        } else {
            println("Invalid note selection.")
        }
    }

        fun deleteNote(index: Int) {
        val dir = File(notesDirectory)
        val files = dir.listFiles()
        if (files != null && index in 1..files.size) {
            if (files[index - 1].delete()) {
                println("Note deleted.")
            } else {
                println("Failed to delete note.")
            }
        } else {
            println("Invalid note selection.")
        }
    }
}

fun main() {
    val scanner = Scanner(System.`in`)
    val user = User("Ion Ionescu")
    val noteManager = NoteManager("notes")

    while (true) {
        println("\nWelcome, ${user.name}")
        println("1. List notes")
        println("2. Create a new note")
        println("3. Load a note")
        println("4. Delete a note")
        println("5. Exit")

        when (scanner.nextLine()) {
            "1" -> {
                noteManager.listNotes()
            }
            "2" -> {
                println("Enter note content:")
                val content = scanner.nextLine()
                val note = Note(user.name, content)
                noteManager.createNote(note)
            }
            "3" -> {
                println("Enter the note number to load:")
                val noteIndex = scanner.nextLine().toIntOrNull()
                if (noteIndex != null) {
                    noteManager.loadNote(noteIndex)
                } else {
                    println("Invalid input.")
                }
            }
            "4" -> {
                println("Enter the note number to delete:")
                val noteIndex = scanner.nextLine().toIntOrNull()
                if (noteIndex != null) {
                    noteManager.deleteNote(noteIndex)
                } else {
                    println("Invalid input.")
                }
            }
            "5" -> {
                println("Goodbye!")
                break
            }
            else -> println("Invalid option, try again.")
        }
    }
}

import os
import collections


def create_test_files(directory):
    os.makedirs(directory, exist_ok=True)

    with open(os.path.join(directory, "text_ascii.txt"), "w", encoding="utf-8") as f:
        f.write("Acesta este un fișier text ASCII/UTF-8. Contine doar caractere tipice.\n")

    with open(os.path.join(directory, "text_unicode.txt"), "w", encoding="utf-16") as f:
        f.write("Acesta este un text în UTF-16.\nMai multe caractere.\n")

    with open(os.path.join(directory, "binary_file.bin"), "wb") as f:
        f.write(os.urandom(1024))

    with open(os.path.join(directory, "mixed_file.dat"), "wb") as f:
        f.write(b"Acest text are caractere ciudate\x00\x01\x02\xFE\xFF")



def detect_file_type(file_path, debug=False):
    try:
        with open(file_path, "rb") as f:
            data = f.read()
            if not data:
                return "Fișier gol"

            total_chars = len(data)
            freq = collections.Counter(data)

            ascii_chars = sum(freq[c] for c in range(32, 127))
            non_ascii_chars = total_chars - ascii_chars
            zero_count = freq[0]

            ascii_ratio = (ascii_chars / total_chars) * 100
            zero_percentage = (zero_count / total_chars) * 100

            if debug:
                print(f"\nDEBUG: {file_path}")
                print(f"Total caractere: {total_chars}")
                print(f"ASCII: {ascii_chars} ({ascii_ratio:.2f}%)")
                print(f"NULL (0x00): {zero_count} ({zero_percentage:.2f}%)")

            if zero_percentage > 30:
                return "Text Unicode/UTF-16"
            elif ascii_ratio > 90:
                return "Text ASCII/UTF-8"
            elif total_chars > 500 and ascii_ratio < 50:
                return "Binar"
            else:
                return "Necunoscut"

    except Exception as e:
        return f"Eroare la citire: {e}"


def scan_directory(directory, debug=False):
    print(f"Scanare fișiere în {directory}...\n")
    for file_name in os.listdir(directory):
        file_path = os.path.join(directory, file_name)
        if os.path.isfile(file_path):
            file_type = detect_file_type(file_path, debug=debug)
            print(f"{file_name}: {file_type}")


if __name__ == "__main__":
    test_directory = "test_files"
    create_test_files(test_directory)
    scan_directory(test_directory, debug=True)

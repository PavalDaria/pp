import os
import struct
import xml.etree.ElementTree as ET
from abc import ABC, abstractmethod


class GenericFile(ABC):
    @abstractmethod
    def get_path(self):
        raise NotImplementedError("Must implement get_path")
    @abstractmethod
    def get_freq(self):
        raise NotImplementedError("Must implement get_freq")


class TextASCII(GenericFile):
    def __init__(self, path):
        self.path_absolut = path
        self.frecvente = self.calculate_freq()

    def get_path(self):
        return self.path_absolut

    def get_freq(self):
        return self.frecvente

    def calculate_freq(self):
        with open(self.path_absolut, 'r', encoding='utf-8', errors='ignore') as f:
            text = f.read()
        return {char: text.count(char) for char in set(text)}


class TextUNICODE(GenericFile):
    def __init__(self, path):
        self.path_absolut = path
        self.frecvente = self.calculate_freq()

    def get_path(self):
        return self.path_absolut

    def get_freq(self):
        return self.frecvente

    def calculate_freq(self):
        with open(self.path_absolut, 'r', encoding='utf-16', errors='ignore') as f:
            text = f.read()
        return {char: text.count(char) for char in set(text)}


class XMLFile(TextASCII):
    def __init__(self, path):
        super().__init__(path)
        self.first_tag = self.get_first_tag()

    def get_first_tag(self):
        try:
            tree = ET.parse(self.path_absolut)
            root = tree.getroot()
            return root.tag
        except Exception:
            return "Unknown"


class Binary(GenericFile):
    def __init__(self, path):
        self.path_absolut = path
        self.frecvente = self.calculate_freq()

    def get_path(self):
        return self.path_absolut

    def get_freq(self):
        return self.frecvente

    def calculate_freq(self):
        with open(self.path_absolut, 'rb') as f:
            data = f.read()
        return {byte: data.count(byte) for byte in set(data)}


class BMP(Binary):
    def __init__(self, path):
        super().__init__(path)
        self.width, self.height, self.bpp = self.get_bmp_info()

    def get_bmp_info(self):
        with open(self.path_absolut, 'rb') as f:
            header = f.read(54) #are 54 bytes
            if header[:2] == b'BM':
                width, height, planes, bpp = struct.unpack('<iiHH', header[18:26] + header[26:30])
                return width, height, bpp
        return None, None, None

    def show_info(self):
        return f"BMP {self.width}x{self.height}, {self.bpp} bpp"


def create_test_files(directory):
    os.makedirs(directory, exist_ok=True)

    with open(os.path.join(directory, "test.xml"), "w", encoding="utf-8") as f:
        f.write("""<?xml version="1.0" encoding="UTF-8"?>
    <root>
        <child>Data</child>
    </root>""")

    with open(os.path.join(directory, "unicode.txt"), "w", encoding="utf-16") as f:
        f.write("Acesta este un fișier UNICODE. Conține caractere specifice.")

    with open(os.path.join(directory, "test.bmp"), "wb") as f:
        f.write(b'BM' + struct.pack('<IHHIIIIHHIIIIII', 54 + 100 * 100 * 3, 0, 0, 54, 40, 100, 100, 1, 24, 0, 0, 0, 0, 0, 0))
        f.write(b'\x00' * (100 * 100 * 3))


def scan_directory(directory):
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                with open(file_path, 'rb') as f:
                    data = f.read(1024)
                    if data[:2] == b'BM':  # BMP file
                        bmp = BMP(file_path)
                        print(f"BMP: {bmp.get_path()} -> {bmp.show_info()}")
                    elif file.endswith('.xml'):
                        xml_file = XMLFile(file_path)
                        print(f"XML: {xml_file.get_path()} -> First tag: {xml_file.first_tag}")
                    else:
                        text_sample = data[:100].decode('utf-8', errors='ignore')
                        if '\x00' in text_sample:
                            unicode_file = TextUNICODE(file_path)
                            print(f"UNICODE: {unicode_file.get_path()}")
                        else:
                            ascii_file = TextASCII(file_path)
                            print(f"ASCII: {ascii_file.get_path()}")
            except Exception as e:
                print(f"Eroare la procesarea fișierului {file_path}: {e}")


directory_to_scan = "test_files"
create_test_files(directory_to_scan)
scan_directory(directory_to_scan)

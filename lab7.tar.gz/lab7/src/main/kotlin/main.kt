import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.LinkedHashMap

// Clasa principală ce implementează Comparable
data class HistoryLogRecord(
    val timestamp: Long,
    val commandLine: String,
    val startDateRaw: String
) : Comparable<HistoryLogRecord> {
    override fun compareTo(other: HistoryLogRecord): Int {
        return timestamp.compareTo(other.timestamp)
    }
}

// Funcție pentru parsarea fișierului log
fun parseHistoryLog(filePath: String): MutableMap<Long, HistoryLogRecord> {
    val logMap = LinkedHashMap<Long, HistoryLogRecord>()
    val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

    var currentStartDate: String? = null
    var currentCommand: String? = null

    File(filePath).forEachLine { line ->
        when {
            line.startsWith("Start-Date:") -> {
                currentStartDate = line.removePrefix("Start-Date:").trim()
            }
            line.startsWith("Commandline:") -> {
                currentCommand = line.removePrefix("Commandline:").trim()
            }
            line.startsWith("End-Date:") && currentStartDate != null && currentCommand != null -> {
                val timestamp = dateFormat.parse(currentStartDate)!!.time
                val record = HistoryLogRecord(timestamp, currentCommand!!, currentStartDate!!)
                logMap[timestamp] = record
                currentStartDate = null
                currentCommand = null
            }
        }
    }

    return logMap.entries
        .sortedByDescending { it.key }
        .take(50)
        .associate { it.key to it.value }
        .toMutableMap()
}

// Funcție generică pentru comparare (cel mai recent record)
fun <T : Comparable<T>> maxRecords(a: T, b: T): T {
    return if (a > b) a else b
}

// Funcție de înlocuire fără generics
fun replaceRecord(
    old: HistoryLogRecord,
    new: HistoryLogRecord,
    map: MutableMap<Long, HistoryLogRecord>
) {
    if (map.containsKey(old.timestamp)) {
        map[old.timestamp] = new
    }
}

fun main() {
    val logFilePath = object {}.javaClass.getResource("/mock_history.log")?.path
        ?: throw Exception("Fișierul mock_history.log nu a fost găsit!")

    val logMap = parseHistoryLog(logFilePath)

    println("== Ultimele 50 de intrări ==")
    logMap.values.forEach { println(it) }

    val records = logMap.values.toList()
    if (records.size >= 2) {
        val maxRecord = maxRecords(records[0], records[1])
        println("\nMai recentă dintre primele două: $maxRecord")
    }

    // Test înlocuire
    println("\nÎnlocuim comanda:")
    val old = records[0]
    val new = old.copy(commandLine = "echo \"Înlocuire test\"")
    replaceRecord(old, new, logMap)

    println("După înlocuire:")
    println(logMap[old.timestamp])
}

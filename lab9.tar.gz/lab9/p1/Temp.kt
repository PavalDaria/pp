fun main() {
    println("Salut din Kotlin!")
}

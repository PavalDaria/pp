public class TempJava {
    public static void main(String[] args) {
        System.out.println("Salut din Java!");
    }
}

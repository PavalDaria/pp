import subprocess
import os

# =========================
# Chain of Responsibility
# =========================

class FileTypeHandler:
    def __init__(self, successor=None):
        self.successor = successor

    def handle(self, content):
        raise NotImplementedError


class PythonHandler(FileTypeHandler):
    def handle(self, content):
        if 'def ' in content or 'import ' in content:
            return 'python'
        elif self.successor:
            return self.successor.handle(content)
        return None


class JavaHandler(FileTypeHandler):
    def handle(self, content):
        if 'public static void main' in content or 'import java.' in content:
            return 'java'
        elif self.successor:
            return self.successor.handle(content)
        return None


class BashHandler(FileTypeHandler):
    def handle(self, content):
        if content.startswith('#!/bin/bash') or 'echo ' in content:
            return 'bash'
        elif self.successor:
            return self.successor.handle(content)
        return None


class KotlinHandler(FileTypeHandler):
    def handle(self, content):
        if 'fun main' in content or 'when (' in content:
            return 'kotlin'
        elif self.successor:
            return self.successor.handle(content)
        return None


# ===================
# Command Pattern
# ===================

class ExecuteCommand:
    def execute(self, filepath):
        raise NotImplementedError


class PythonCommand(ExecuteCommand):
    def execute(self, filepath):
        return subprocess.getoutput(f'python3 {filepath}')


class JavaCommand(ExecuteCommand):
    def execute(self, filepath):
        # Salvare temporară pentru Java
        java_filename = "TempJava.java"
        with open(java_filename, "w") as f:
            f.write(open(filepath).read())

        compile_output = subprocess.getoutput(f"javac {java_filename}")
        if compile_output:
            return compile_output
        return subprocess.getoutput("java TempJava")


class BashCommand(ExecuteCommand):
    def execute(self, filepath):
        return subprocess.getoutput(f"bash {filepath}")


class KotlinCommand(ExecuteCommand):
    def execute(self, filepath):
        class_name = "MainKt"
        tmp_kotlin_file = "Temp.kt"
        with open(tmp_kotlin_file, "w") as f:
            f.write(open(filepath).read())

        compile_output = subprocess.getoutput(f"kotlinc {tmp_kotlin_file} -include-runtime -d Temp.jar")
        if compile_output:
            return compile_output
        return subprocess.getoutput("java -jar Temp.jar")


# ======================
# Aplicație principală
# ======================

def main():
    filename = input("Introduceți numele fișierului (fără extensie): ")

    if not os.path.isfile(filename):
        print("Fișierul nu există.")
        return

    with open(filename, 'r') as f:
        content = f.read()

    # Chain of Responsibility setup
    handler_chain = PythonHandler(JavaHandler(BashHandler(KotlinHandler())))

    language = handler_chain.handle(content)

    if not language:
        print("Limbaj necunoscut.")
        return

    # Command Pattern
    commands = {
        'python': PythonCommand(),
        'java': JavaCommand(),
        'bash': BashCommand(),
        'kotlin': KotlinCommand()
    }

    command = commands.get(language)
    if command:
        print(f"[INFO] Limbaj detectat: {language}")
        result = command.execute(filename)
        print("[OUTPUT]")
        print(result)


if __name__ == '__main__':
    main()

from abc import ABC, abstractmethod

# ============ Observer Pattern ============
class Observer(ABC):
    @abstractmethod
    def update(self, subject):
        pass

class Observable:
    def __init__(self):
        self._observers = []

    def attach(self, observer: Observer):
        self._observers.append(observer)

    def detach(self, observer: Observer):
        self._observers.remove(observer)

    def notify(self):
        for obs in self._observers:
            obs.update(self)

# ============= TakeMoneySTM =============
class State(ABC):
    def __init__(self, machine):
        self.machine = machine

    @abstractmethod
    def on_event(self, event):
        pass

class WaitingForClient(State):
    def on_event(self, event):
        if event in ('insert_10bani', 'insert_50bani', 'insert_1leu', 'insert_5lei', 'insert_10lei'):
            return self.machine.insert_money_state
        return self

class InsertMoney(State):
    def on_event(self, event):
        mapping = {
            'insert_10bani': 10,
            'insert_50bani': 50,
            'insert_1leu': 100,
            'insert_5lei': 500,
            'insert_10lei': 1000
        }
        if event in mapping:
            self.machine.money += mapping[event]
        return self.machine.waiting_state

class TakeMoneySTM(Observable):
    def __init__(self):
        super().__init__()
        self.money = 0
        self.waiting_state = WaitingForClient(self)
        self.insert_money_state = InsertMoney(self)
        self.current_state = self.waiting_state

    def on_event(self, event):
        self.current_state = self.current_state.on_event(event)
        self.notify()

    # Helper methods matching UML
    def insert_10bani(self): self.on_event('insert_10bani')
    def insert_50bani(self): self.on_event('insert_50bani')
    def insert_1leu(self): self.on_event('insert_1leu')
    def insert_5lei(self): self.on_event('insert_5lei')
    def insert_10lei(self): self.on_event('insert_10lei')

# ========= SelectProductSTM ============
class SelectProductState(ABC):
    def __init__(self, machine):
        self.machine = machine

    @abstractmethod
    def choose(self):
        pass

class SelectProductSTM(Observable):
    def __init__(self):
        super().__init__()
        # instantiate each concrete state
        self.select_product_state = SelectProduct(self)
        self.coca_cola_state = CocaCola(self)
        self.pepsi_state = Pepsi(self)
        self.sprite_state = Sprite(self)
        self.current_state = self.select_product_state
        self.selected = None

    def choose(self, product_name):
        mapping = {
            'Cola': self.coca_cola_state,
            'Pepsi': self.pepsi_state,
            'Sprite': self.sprite_state
        }
        state = mapping.get(product_name, self.select_product_state)
        self.current_state = state
        self.current_state.choose()
        self.notify()

    def choose_another_product(self):
        self.current_state = self.select_product_state
        self.selected = None
        self.notify()

class SelectProduct(SelectProductState):
    def choose(self):
        # invalid selection
        self.machine.selected = None

class CocaCola(SelectProductState):
    def choose(self):
        self.machine.selected = 'Cola'

class Pepsi(SelectProductState):
    def choose(self):
        self.machine.selected = 'Pepsi'

class Sprite(SelectProductState):
    def choose(self):
        self.machine.selected = 'Sprite'

# ========== VendingMachineSTM ============
class VendingMachineSTM(Observable):
    def __init__(self, products: dict):
        super().__init__()
        self.products = products
        self.take_money_stm = TakeMoneySTM()
        self.select_product_stm = SelectProductSTM()
        self.last_message = ''
        # attach observers
        self.take_money_stm.attach(DisplayObserver())
        self.select_product_stm.attach(SelectObserver(self))
        self.attach(ChoiceObserver())

    def insert_money(self, denomination_method):
        # call the STM method by name
        getattr(self.take_money_stm, denomination_method)()

    def select(self, product_name):
        self.select_product_stm.choose(product_name)
        selected = self.select_product_stm.selected
        if selected:
            price = self.products[selected]
            balance = self.take_money_stm.money
            if balance >= price:
                change = balance - price
                self.last_message = f"Produs '{selected}' livrat! Rest: {change} lei"
                self.take_money_stm.money = 0
            else:
                needed = price - balance
                self.last_message = f"Fonduri insuficiente. Lipsesc {needed} lei."
        else:
            self.last_message = "Produs invalid sau nerecunoscut."
        # notify ChoiceObserver
        self.notify()

# ========== Observers ============
class DisplayObserver(Observer):
    def update(self, subject):
        # subject is TakeMoneySTM
        print(f"Suma introduse: {subject.money} bani")

class SelectObserver(Observer):
    def __init__(self, vending_machine):
        self.vm = vending_machine

    def update(self, subject):
        # subject is SelectProductSTM
        sel = subject.selected
        if sel:
            print(f"Ati selectat: {sel}")
        else:
            print("Selectie invalida")

class ChoiceObserver(Observer):
    def update(self, subject):
        # subject is VendingMachineSTM
        print(subject.last_message)

# ========== Main Simulation ===========
if __name__ == '__main__':
    products = {'Cola': 500, 'Pepsi': 400, 'Sprite': 600}
    vm = VendingMachineSTM(products)

    print("=== Vending Machine ===")
    while True:
        cmd = input("i: 10bani, I:50bani, l:1leu, L:5lei, X:10lei, s: select, q: quit> ")
        if cmd == 'i': vm.insert_money('insert_10bani')
        elif cmd == 'I': vm.insert_money('insert_50bani')
        elif cmd == 'l': vm.insert_money('insert_1leu')
        elif cmd == 'L': vm.insert_money('insert_5lei')
        elif cmd == 'X': vm.insert_money('insert_10lei')
        elif cmd == 's':
            print("Produse:", ', '.join(products.keys()))
            name = input("Alege produs: ")
            vm.select(name)
        elif cmd == 'q':
            print("La revedere!")
            break
        else:
            print("Comanda necunoscuta.")

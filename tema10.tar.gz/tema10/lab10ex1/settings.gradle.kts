
rootProject.name = "lab10ex1"


import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking

interface AbstractFactory {
    fun getHandler(handler: String): Handler
}

class FactoryProducer {
    fun getFactory(choice: String): AbstractFactory {
        return when (choice) {
            "Elite" -> EliteFactory()
            "Worker" -> HappyWorkerFactory()
            else -> throw IllegalArgumentException("No such factory")
        }
    }
}

interface Handler {
    var next1: Handler? // cerere
    var next2: Handler? // raspuns
    suspend fun handleRequest(messageToBeProcessed: String)
}

class CEOHandler : Handler {
    override var next1: Handler? = null
    override var next2: Handler? = null

    override suspend fun handleRequest(messageToBeProcessed: String) {
        if (messageToBeProcessed.startsWith("Request") && messageToBeProcessed.contains("CEO")) {
            println("Processing by CEO: $messageToBeProcessed")
            delay(1000)
            next2?.handleRequest("Response - Processed by CEO")
        } else if (messageToBeProcessed.startsWith("Response")) {
            println("CEO received response: $messageToBeProcessed")
        } else {
            next1?.handleRequest(messageToBeProcessed)
        }
    }
}

class ExecutiveHandler : Handler {
    override var next1: Handler? = null
    override var next2: Handler? = null

    override suspend fun handleRequest(messageToBeProcessed: String) {
        if (messageToBeProcessed.startsWith("Request") && messageToBeProcessed.contains("Executive")) {
            println("Processing by Executive: $messageToBeProcessed")
            delay(500)
            next2?.handleRequest("Response - Processed by Executive")
        } else if (messageToBeProcessed.startsWith("Response")) {
            println("Executive received response: $messageToBeProcessed")
            next2?.handleRequest(messageToBeProcessed)
        } else {
            next1?.handleRequest(messageToBeProcessed)
        }
    }
}

class ManagerHandler : Handler {
    override var next1: Handler? = null
    override var next2: Handler? = null

    override suspend fun handleRequest(messageToBeProcessed: String) {
        if (messageToBeProcessed.startsWith("Request") && messageToBeProcessed.contains("Manager")) {
            println("Processing by Manager: $messageToBeProcessed")
            delay(800)
            next2?.handleRequest("Response - Processed by Manager")
        } else if (messageToBeProcessed.startsWith("Response")) {
            println("Manager received response: $messageToBeProcessed")
            next2?.handleRequest(messageToBeProcessed)
        } else {
            next1?.handleRequest(messageToBeProcessed)
        }
    }
}

class HappyWorkerHandler : Handler {
    override var next1: Handler? = null
    override var next2: Handler? = null

    override suspend fun handleRequest(messageToBeProcessed: String) {
        if (messageToBeProcessed.startsWith("Request") && messageToBeProcessed.contains("Worker")) {
            println("Processing by Worker: $messageToBeProcessed")
            delay(300)
            next2?.handleRequest("Response - Processed by Worker")
        } else if (messageToBeProcessed.startsWith("Response")) {
            println("Worker received response: $messageToBeProcessed")
        } else {
            println("Worker cannot handle: $messageToBeProcessed")
        }
    }
}

class EliteFactory : AbstractFactory {
    override fun getHandler(handler: String): Handler {
        return when (handler) {
            "CEO" -> CEOHandler()
            "Executive" -> ExecutiveHandler()
            "Manager" -> ManagerHandler()
            else -> throw IllegalArgumentException("No handler")
        }
    }
}

class HappyWorkerFactory : AbstractFactory {
    override fun getHandler(handler: String): Handler {
        return when (handler) {
            "Worker" -> HappyWorkerHandler()
            else -> throw IllegalArgumentException("No handler")
        }
    }
}

fun main() = runBlocking {
    val eliteFactory = EliteFactory()
    val happyWorkerFactory = HappyWorkerFactory()

    val ceo = eliteFactory.getHandler("CEO") as CEOHandler
    val executive = eliteFactory.getHandler("Executive") as ExecutiveHandler
    val manager = eliteFactory.getHandler("Manager") as ManagerHandler
    val worker = happyWorkerFactory.getHandler("Worker") as HappyWorkerHandler

    ceo.next1 = executive
    executive.next1 = manager
    manager.next1 = worker

    manager.next2 = executive
    executive.next2 = ceo
    worker.next2 = manager

    ceo.handleRequest("Request - Executive needs processing")
    println("----")
    ceo.handleRequest("Request - Worker needs processing")
    println("----")
    ceo.handleRequest("Request - Manager needs processing")
}

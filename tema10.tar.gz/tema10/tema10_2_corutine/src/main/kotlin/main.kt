import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel

suspend fun source(cout: Channel<Int>, V: List<Int>, alpha: Int){
    println("Source starting")
    for(x in V){
        cout.send(x * alpha)
    }
    cout.close()
    println("Source exiting")
}
suspend fun filter(cin: Channel<Int>, cout: Channel<List<Int>>){
    println("Filter starting")
    val list = mutableListOf<Int>()
    for(x in cin){
        println("Filter received $x")
        list.add(x)
    }
    list.sort()
    cout.send(list)
    cout.close()
    println("Filter exiting")
}
suspend fun output(cin: Channel<List<Int>>){
    println("Output starting")
    for(x in cin){
        println("rezultat final: $x")
    }
    println("Output exiting")
}

fun runAll(){
    runBlocking {
        println("RunAll starting")
        val V = listOf(4,2,7,1,9)
        val alpha = 2
        val pipe1 = Channel<Int>(5)
        val pipe2 = Channel<List<Int>>(1)
        GlobalScope.launch {
            launch { source(pipe1, V, alpha) }
            launch { filter(pipe1,pipe2) }
            launch { output(pipe2) }
        }.join()
    }
    println("runAll exiting")
}
fun main(){
    runAll()
}
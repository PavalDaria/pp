package com.pp.lab

import java.util.concurrent.BlockingQueue
import java.util.concurrent.LinkedBlockingQueue

fun main(args: Array<String>){
    val queue1: BlockingQueue<List<Int>> = LinkedBlockingQueue()
    val queue2: BlockingQueue<List<Int>> = LinkedBlockingQueue()

    val thread = Thread {
        val input = listOf(4,2,7,1,9)
        val alpha = 2
        val cout = input.map{ it * alpha}
        queue1.put(cout)
    }
    thread.start()
    thread.join()
    val sorted = Thread{
        val data = queue1.take().toMutableList()
        data.sort()
        queue2.put(data)
    }
    sorted.start()
    sorted.join()
    val printer = Thread{
        val result = queue2.take()
        println("rezultat final: $result")
    }
    printer.start()
    printer.join()
}
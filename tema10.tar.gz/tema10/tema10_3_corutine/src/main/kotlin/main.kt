import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel

suspend fun source(cout: Channel<Int>, V: List<Int>){
    for(x in V){
        cout.send(x)
    }
    cout.close()
}
suspend fun sum(cin: Channel<Int>, id: Int){
    for(x in cin){
        delay(100L)
        val suma= (1..x).sum()
        println("Worker $id: suma dela 1 la $x = $suma")
    }
}

fun main(){
    runBlocking {
        val V = listOf(4,2,7,1)
        val pipe = Channel<Int>(4)
        launch { source(pipe, V) }

        repeat(4) { i ->
            launch { sum(pipe, i + 1) }
        }
    }
}
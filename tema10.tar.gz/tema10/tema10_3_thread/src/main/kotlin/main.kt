package com.pp.lab

import java.util.concurrent.BlockingQueue
import java.util.concurrent.LinkedBlockingQueue

fun main(){
    val queue: BlockingQueue<Int> = LinkedBlockingQueue()
    val input = listOf(4,2,7,1)
    input.forEach{ queue.put(it) }

    val threads = List(4){
        Thread {
            while (queue.isNotEmpty()) {
                val n = queue.poll() ?: break
                val suma = (1..n).sum()
                println(" Thread $it: suma de la 1 la $n = $suma")
            }
        }
    }
    threads.forEach { it.start() }
    threads.forEach { it.join() }
}
package com.pp.lab
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*
import java.io.File

sealed class FileContent
data class FileProcessing(val fileName: String) : FileContent()

fun CoroutineScope.fileActor(id: Int) = actor<FileContent> {

    for (msg in channel) {
        when (msg) {
            is FileProcessing -> {
                val content = File(msg.fileName).readText()
                println("Actor $id fisier: ${msg.fileName}, continut: $content")
            }
        }
    }
}

fun main() = runBlocking<Unit> {

    val actorCount = 3
    val actors = List(actorCount) { i -> fileActor(i+1) }

    val files = listOf(
        "src/main/resources/fisier1.txt",
        "src/main/resources/fisier2.txt",
        "src/main/resources/fisier3.txt"
    )
    files.forEachIndexed { index, file ->
        actors[index].send(FileProcessing(file))
    }

    actors.forEach { it.close() }

}
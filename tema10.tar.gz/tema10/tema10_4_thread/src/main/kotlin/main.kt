package org.example

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.newFixedThreadPoolContext
import kotlinx.coroutines.*
import java.io.File

fun fileProcessing(fileName: String){
        val content = File(fileName).readText()
        println("Fisier: ${fileName}, continut: $content")
    }

fun main() = runBlocking<Unit> {
   // val mtContext = newFixedThreadPoolContext(3, "mtPool")
    val files = listOf("src/main/resources/fisier1.txt", "src/main/resources/fisier2.txt", "src/main/resources/fisier3.txt")
    val threads = mutableListOf<Thread>()
    for (file in files){
        val thread = Thread{
            fileProcessing(file)
        }
        threads.add(thread)
    }
    threads.forEach{ it.start()}
    threads.forEach{ it.join()}

}
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.jsoup.Jsoup
import org.jsoup.nodes.Element

suspend fun source(cout: Channel<String>, url: String){
    try {
        val document = Jsoup.connect(url).get()
        cout.send(document.toString())
    } catch (e: Exception) {
        println("Eroare la accesarea URL-ului: $url") }
    cout.close()
}
suspend fun DOMtreeParser(cin: Channel<String>, cout: Channel<Element>){
    for (html in cin) {
        val doc = Jsoup.parse(html)
        cout.send(doc)
    }
    cout.close()
}

suspend fun DOMtreePrinter(cin: Channel<Element>){
    for (r in cin) {
        println(" Afișează arborele DOM:\n")
        printTree(r, 0)
    }
}
fun printTree(element: Element, indent: Int) {
    val indentStr = "  ".repeat(indent)
    println("$indentStr<${element.tagName()}>")

    for (child in element.children()) {
        printTree(child, indent + 1)
    }
}
fun runAll(){
    runBlocking {

        val pipe1 = Channel<String>()
        val pipe2 = Channel<Element>()
        GlobalScope.launch {
            launch { source(pipe1, "http://mike.tuiasi.ro") }
            launch { DOMtreeParser(pipe1,pipe2) }
            launch { DOMtreePrinter(pipe2) }
        }.join()
    }
}
fun main(){
    runAll()
}
fun main() {
    val list1 = listOf(1, 21, 75, 39, 7, 2, 35, 3, 31, 7, 8)
    val list2 = list1.filter{ it >= 5 }
    println(list2)
    val even = list2.filterIndexed { index, i ->  index%2 ==0}
    val odd = list2.filterIndexed { index, i ->  index%2 ==1}
    val list3 = even.zip(odd)
    println(list3)
    val list4 = list3.map{ it.first*it.second }
    println(list4)
    println(list4.sum())
}

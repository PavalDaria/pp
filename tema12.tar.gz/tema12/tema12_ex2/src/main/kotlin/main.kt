import java.io.File

fun cesar(plainText : String, key : Int) : String {
    val alphabet = "abcdefghijklmnopqrstuvwxyz"
    var text = ""
    val plainTextCase = plainText.lowercase()

    for (character in plainTextCase) {
        val characterValue = alphabet.indexOf(character)
        val shiftCharacter = (characterValue + key) % alphabet.length
        text += alphabet[shiftCharacter]
    }
    return text
}
fun processFile(filePath: String, shift: Int) {
    val file = File(filePath)
    val result = file.readLines().map { line ->
        line.split("\\s+".toRegex()).joinToString(" ") { word ->
            if (word.length in 4..7)
                cesar(word, shift)
            else
                word
        }
    }.joinToString("\n")
    println(result)
}


fun main() {
    val filePath = "/home/student/Documents/Tema12/tema12_ex2/src/main/resources/text.txt"
    val shift = 3
    processFile(filePath, shift)
}
import kotlin.math.pow

fun distanta(a: Pair<Int, Int>, b: Pair<Int, Int>): Int{
    return kotlin.math.sqrt((a.first - b.first).toDouble().pow(2) + (a.second - b.second).toDouble().pow(2)).toInt()
}

fun main()
{
    val n = readLine()!!.toInt()
    val list1= List(n) {
        val (x, y) = readLine()!!.split(" ").map { it.toInt() }
        x to y
    }

    val list2 = list1.zipWithNext() + listOf(list1.last()).zip(listOf( list1.first()))
    val perimetru = list2.sumOf { (a,b) -> distanta(a,b) }
    println(perimetru)
}
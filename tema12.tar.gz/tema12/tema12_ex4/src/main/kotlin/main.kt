
fun String.toPascalCase(): String{
    return this.split(" ").joinToString("") { it.capitalize() }
}
class Functor<K, V>(val map: MutableMap<K,V>) {
    fun mapValues(function: (V) -> V): Functor<K,V> {
        val result = map.mapValues{(_, v)-> function(v)}.toMutableMap()
        return Functor(result)
    }
}

fun main() {

    val data = mutableMapOf(1 to "paradigme de programare", 2 to "programare functionala", 3 to "kotlin")
    val result = Functor(data)
        .mapValues { "Test $it" }
        .mapValues { it.toPascalCase() }
    println(result.map)
}

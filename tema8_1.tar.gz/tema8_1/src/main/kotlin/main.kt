
abstract class AndState{
    abstract fun evaluate(Inputs: List<Boolean>): Boolean
}
class ActiveState : AndState() {
    override fun evaluate(Inputs: List<Boolean>): Boolean {
        return Inputs.all { it }
    }
}
class  InactiveState : AndState() {
    override fun evaluate(Inputs: List<Boolean>): Boolean {
        // Cand e inactiv, sa zicem ca mereu returneaza "false"
        return false
    }
}
open class AndFSM{
    var state: AndState = InactiveState()
    open fun evaluate(Inputs: List<Boolean>): Boolean{
        return state.evaluate(Inputs)
    }
    fun activate() {
        state = ActiveState()
    }

    fun deactivate() {
        state = InactiveState()
    }
}


interface LogicGateImplementor{
    fun compute(inputs: List<Boolean>): Boolean
}
abstract class LogicGate(protected val implementor: LogicGateImplementor)
{
    protected val inputs = mutableListOf<Boolean>()
    fun setInputs(newInputs: List<Boolean>){
        inputs.clear()
        inputs.addAll(newInputs)
    }
    abstract  fun getOutput(): Boolean
}
class AndGate(impementor: LogicGateImplementor): LogicGate(impementor)
{
    override fun getOutput(): Boolean {
        return implementor.compute(inputs)
    }
}
class AndGateImplementor(private val fsm: AndFSM): LogicGateImplementor{
    override fun compute(inputs: List<Boolean>): Boolean {
        return fsm.evaluate(inputs)
    }
}


interface GateBuilder{
    fun addInput(Input: Boolean): GateBuilder
    fun build(): LogicGate
}
class AndGateBuilder: GateBuilder{
    private val inputs = mutableListOf<Boolean>()

    override fun addInput(Input: Boolean): GateBuilder {
        inputs.add(Input)
        return this
    }
    override fun build(): LogicGate {
        val fsm = AndFSM()
        fsm.activate() // Activam FSM-ul ca default!
        val gate = AndGate(AndGateImplementor(fsm))
        gate.setInputs(inputs)
        return gate
    }

}
fun main() {
    println("Poarta AND cu 2 intrari")
    val gate2 = AndGateBuilder()
        .addInput(true)
        .addInput(false)
        .build()
    println("Output: ${gate2.getOutput()}")

    println("Poarta AND cu 3 intrari")
    val gate3 = AndGateBuilder()
        .addInput(true)
        .addInput(true)
        .addInput(true)
        .build()
    println("Output: ${gate3.getOutput()}")

    println("Poarta AND cu 4 intrari")
    val gate4 = AndGateBuilder()
        .addInput(true)
        .addInput(true)
        .addInput(true)
        .addInput(false)
        .build()
    println("Output: ${gate4.getOutput()}")

    println("Poarta AND cu 8 intrari")
    val gate8 = AndGateBuilder()
        .addInput(true).addInput(true).addInput(true).addInput(true)
        .addInput(true).addInput(true).addInput(true).addInput(true)
        .build()
    println("Output: ${gate8.getOutput()}")
}

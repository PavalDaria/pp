package org.example
import khttp.responses.Response

interface Cloneable { fun clone(): GenericRequest }
class GenericRequest(var  url: String,
                     var params: Map<String, String>? ): Cloneable{

    override fun clone(): GenericRequest {
        return GenericRequest(url, params?.toMap())
    }
}
interface HTTPGet { fun getResponse(): Response? }
class GetRequest(var timeout: Int,
                 var genericReq: GenericRequest): HTTPGet{

    override fun getResponse(): Response
    {
        return khttp.get(genericReq.url, params = genericReq.params!!, timeout = timeout.toDouble())
    }
}
class CleanGetRequest(private var getRequest: GetRequest, private val parentalControlDisallow: List<String>): HTTPGet
{
    override fun getResponse(): Response? {
        for(badWord in parentalControlDisallow){
            if( getRequest.genericReq.url.contains(badWord))
            {
                println("Acces interzis")
                return null
            }
        }
        return getRequest.getResponse()
    }
}
class PostRequest(private var genericReq: GenericRequest){
    fun postData(): Response{
        return khttp.post(genericReq.url, data = genericReq.params)
    }
}
class KidsBrowser( private var cleanGet: CleanGetRequest, private var postReq: PostRequest?)
{
    fun start(){
        println("Start browsing")
        cleanGet.getResponse()
        postReq?.postData()
    }

}
fun main() {
    val generic = GenericRequest("https://httpbin.org/get", mapOf("name" to "Maria")) //https://httpbin.org/ site special pt testare
    val clone = generic.clone()

    val getReq = GetRequest( timeout = 5 , clone)
    val cleanGet = CleanGetRequest(getReq, listOf("httpbin.org", "youtube"))

    val postReq = PostRequest(GenericRequest("https://httpbin.org/post", mapOf("data" to "123")))

    val browser = KidsBrowser(cleanGet, postReq)

    browser.start()
}


